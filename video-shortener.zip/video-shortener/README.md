# Video Shortener (Browser)

This is a small ready-to-run web app that splits long videos into 30–60 second clips entirely in the browser using FFmpeg.wasm. Nothing is uploaded to any server — all processing is client-side.

## How to use locally
1. Download `index.html` and open it in Chrome or Edge (modern browsers recommended).
2. Select a video file, choose clip length (30–60s) and click **Load FFmpeg & Split**.
3. After processing, individual clips will appear with download links.

## How to publish on GitHub Pages
1. Create a new repository like `video-shortener` on GitHub.
2. Add these files (`index.html`, `README.md`, `LICENSE`) and push to the `main` branch.
3. In the repo settings -> Pages, choose `main` branch and `/ (root)` as the folder and save.
4. Your site will be published at `https://<your-username>.github.io/video-shortener/` within a minute or two.

## Notes & caveats
- Large files may use a lot of memory — for very long videos, prefer trimming locally first.
- FFmpeg.wasm downloads a wasm binary from CDN on first load; users need an internet connection.
- Mobile browsers may be limited by memory and CPU.

## License
MIT — see LICENSE file.
